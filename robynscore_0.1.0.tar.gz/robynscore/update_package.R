###set wd
rm(list=ls()); gc()
library(stringr)
script_path <- str_sub(rstudioapi::getActiveDocumentContext()$path, start = 1, end = max(unlist(str_locate_all(rstudioapi::getActiveDocumentContext()$path, "/"))))

# update description
#script_path <- "D:/python/jupyter/BO100/demo_model/newi/20211222_no_prophet/"
setwd(script_path)

library(devtools)
library(roxygen2)
devtools::document()
check() # 不用每次都跑
#Build - Build source package
#https://www.jianshu.com/p/46442fd976ed?ivk_sa=1024320u
#install.packages("D:/loreal/digitalMMM/digital/robynscore_0.1.0.tar.gz", repos = NULL, type = "source")
