
#' Step calculator with set spd_high & spd_low
#'
#' @param w Vector. original spd
#' @param step Numeric.
#' @param spd_high Vector.
#' @param spd_low Vector.
#'
#' @return
#' @export
#'
#' @examples
change.f<-function(w,step,spd_high,spd_low){
  w_change<-w+step
  w_change[w_change>spd_high]<-w[w_change>spd_high]
  w_change[w_change<spd_low]<-w[w_change<spd_low]
  return(w_change-w)
}


#' Budget allocation with unchanged ttl spd
#'
#' @param media_need
#' @param model_input
#' @param old_spd
#' @param spd_range
#' @param promo_range
#' @param high_ratio Numeric or Vector same order as media_need
#' @param low_ratio Numeric or Vector same order as media_need
#'
#' @return
#' @export
#'
#' @examples
budget_spd_unchange<-function(media_need,model_input,
                              old_spd=NA,spd_range=NA,promo_range=NA,atv=NA,
                              high_ratio=1.15,low_ratio=0.85){
  if(is.na(promo_range[1])){
    promo_range<-c(model_input$model_start,model_input$model_end)
  }

  if(is.na(spd_range[1])){
    spd_range<-promo_range
  }

  if(is.na(atv)){
    atv <- atv_cal(model_input,promo_range)
  }

  if(is.na(old_spd[1])){
    old_spd <- foreach(media = media_need, .combine = 'c') %do% {
      nv(media_result_all(media=media,model_input,spd_range,promo_range)$spd,media)
    }
  }
  spd_ttl<-sum(old_spd);spd_ttl

  spd_high<-old_spd

  spd_high<- high_ratio * spd_high

  spd_low<-old_spd

  spd_low<-low_ratio * spd_low
  x0<-old_spd


  np_orig<-sum(mapply(media_response,
                 media=media_need,
                 model_input=rep(list(model_input),length(media_need)),
                 spd_range = rep(list(spd_range),length(media_need)),
                 promo_range =rep(list(promo_range),length(media_need)),
                 spd_new=x0))

  np<-np_orig

  cat(np[length(np)],"\n")

  steps<-c(100000,10000,1000,100,10,1,0.1,0.01,0.001,0.0001,0.00001)
  for(step in steps){
    for(i in 1:1000){
      jia<-mapply(change.f.media,
                  media=media_need,
                  model_input=rep(list(model_input),length(media_need)),
                  spd_range =rep(list(spd_range),length(media_need)),
                  promo_range =rep(list(promo_range),length(media_need)),
                  step=change.f(x0,step,spd_high,spd_low),spd_new=x0)
      jian<-mapply(change.f.media,
                   media=media_need,
                   model_input=rep(list(model_input),length(media_need)),
                   spd_range =rep(list(spd_range),length(media_need)),
                   promo_range =rep(list(promo_range),length(media_need)),
                   step=change.f(x0,-step,spd_high,spd_low),spd_new=x0)


      c_n<-min(length(jia[jia>0]),length(jian[jian<0]))

      criteria<-sort(jia[jia>0],decreasing = T)[1:c_n]+sort(jian[jian<0],decreasing = T)[1:c_n]
      crit_n<-sum(criteria>0.0001)
      if(names(jia[jia>0])[jia[jia>0]==max(jia[jia>0])]==names(jian[jian<0])[jian[jian<0]==max(jian[jian<0])]){
        crit_n<-0
      }

      if(crit_n>0){

        x0[which(jia>0)[order(jia[jia>0],decreasing=T)]][1:crit_n]<- x0[which(jia>0)[order(jia[jia>0],decreasing=T)]][1:crit_n]+step
        x0[which(jian<0)[order(jian[jian<0],decreasing=T)]][1:crit_n]<- x0[which(jian<0)[order(jian[jian<0],decreasing=T)]][1:crit_n]-step



        np<-c(np,sum(mapply(media_response,
                            media=media_need,
                            model_input=rep(list(model_input),length(media_need)),
                            spd_range =rep(list(spd_range),length(media_need)),
                            promo_range =rep(list(promo_range),length(media_need)),
                            spd_new=x0)))
        cat("step ",step,"no.",i,"new NP: ",np[length(np)],"spd unchanged: ",round(sum(x0)-spd_ttl,0)==0,"\n")

      } else{
        cat("step ",step,":succeed!")
        break
      }

    }
  }

  result<-list(new_spd=x0,
               new_np=np,
               old_spd=old_spd,
               old_np=np_orig)

  return(result)

}


#' Budget allocation for a set target
#'
#' @param media_need
#' @param model_input
#' @param tgt
#' @param old_spd
#' @param spd_range
#' @param promo_range
#' @param high_ratio
#' @param low_ratio
#'
#' @return
#' @export
#'
#' @examples
budget_spd_tgt<-function(media_need,model_input,tgt,
                              old_spd=NA,spd_range=NA,promo_range=NA,atv=NA,
                              high_ratio=2,low_ratio=1){
  if(is.na(promo_range[1])){
    promo_range<-c(model_input$model_start,model_input$model_end)
  }

  if(is.na(spd_range[1])){
    spd_range<-promo_range
  }

  if(is.na(atv)){
    atv <- atv_cal(model_input,promo_range)
  }

  if(is.na(old_spd[1])){
    old_spd <- foreach(media = media_need, .combine = 'c') %do% {
      nv(media_result_all(media=media,model_input,promo_range)$spd,media)
    }
  }
  spd_ttl<-sum(old_spd);spd_ttl

  spd_high<-old_spd

  spd_high<- high_ratio * spd_high

  spd_low<-old_spd

  spd_low<-low_ratio * spd_low
  x0<-old_spd


  np_orig<-sum(mapply(media_response,
                      media=media_need,
                      model_input=rep(list(model_input),length(media_need)),
                      promo_range =rep(list(promo_range),length(media_need)),
                      spd_new=x0))

  np<-np_orig

  cat(np[length(np)],"\n")

  steps<-c(100000,10000,1000,100,10,1)
  for(step in steps){
    for(i in 1:1000){
      jia<-mapply(change.f.media,
                  media=media_need,
                  model_input=rep(list(model_input),length(media_need)),
                  promo_range =rep(list(promo_range),length(media_need)),
                  step=change.f(x0,step,spd_high,spd_low),spd_new=x0)

      c_n<-length(jia[jia>0])
      if(c_n==0){break}

      x1<-x0
      x1[jia==max(jia)]<-x1[jia==max(jia)]+step
      np<-c(np,sum(mapply(media_response,
                     media=media_need,
                     model_input=rep(list(model_input),length(media_need)),
                     promo_range =rep(list(promo_range),length(media_need)),
                     spd_new=x1)))

      if(np[length(np)]>tgt){
        cat("step ",step,":succeed!")
        break} else
        {
        x0[jia==max(jia)]<-x0[jia==max(jia)]+step
        cat("step ",step,"no.",i,"new NP: ",np[length(np)],"spd changed: ",round(sum(x0)-spd_ttl,0),"\n")
        }

    }}


  result<-list(new_spd=x0,
               new_np=np,
               old_spd=old_spd,
               old_np=np_orig)

  return(result)

}
