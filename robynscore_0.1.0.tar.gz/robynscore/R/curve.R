
#' Daily Response/mroi curve for all media selected
#'
#' @param media_need
#' @param model_input
#' @param atv
#'
#' @return
#' @export
#'
#' @examples
curveDaily <- function(media_need,model_input,atv=NA)
  {
  if(is.na(atv)){
    atv <- atv_cal(model_input)
  }

  dt_orig<-model_input$dt_orig
  ds <- as.Date(unlist(subset(dt_orig,select=model_input$date_var)),origin=as.Date("1970-01-01"))
  curveDayAll<-data.frame()
  for (i in media_need)
    {
    curveData <-data.frame(ds=ds,
                           media=i,
                           spd = media_result_all(media=i,model_input)$spd_daily,
                           spd_adstock = media_result_all(media=i,model_input)$spd_adstock,
                           response=media_result_all(media=i,model_input)$response_daily)
    curveDaily <- curveData %>% group_by(media,ds) %>%
      summarise(
        spd=sum(spd), spd_adstock=sum(spd_adstock),
        response=sum(response),roi=atv*sum(response)/sum(spd),
        roi.m=atv*(media_result_all(media=i,model_input,promo_range=c(min(ds),max(ds)),step=1)$response -
                     media_result_all(media=i,model_input,promo_range=c(min(ds),max(ds)))$response)
      )

    curveDayAll<-rbind(curveDayAll,curveDaily)


  }
  return(curveDayAll)
}


#' Campaign Response/mroi curve for all media selected
#'
#' @param media_need
#' @param model_input
#' @param promo_range
#' @param atv
#'
#' @return
#' @export
#'
#' @examples
curveCampaign <- function(media_need,model_input,spd_range,promo_range,atv=NA){
  if(is.na(atv)){
    atv <- atv_cal(model_input,promo_range)
  }

  actual_spd <- foreach(media = media_need, .combine = 'c') %do% {
    nv(media_result_all(media=media,model_input,spd_range,promo_range)$spd,media)
  }

  start <- signif(min(actual_spd),digits=1)/10
  end <- signif(max(actual_spd),digits=1) * 2
  step <- ifelse(start==0,end/100,start)

  result_all<-data.frame()
  for(media in media_need){

    spd_actual<-actual_spd[media]
    result<-foreach(media_spd = seq(start,end,step), .combine='rbind')%do%{
      library(Robyn)
      data.frame(media,
                 spd=media_spd,
                 response=media_response(media=media,model_input,spd_range=spd_range,promo_range=promo_range,spd_new=media_spd),
                 roi.m=atv*(media_response(media=media,model_input,spd_range=spd_range,promo_range=promo_range,spd_new=media_spd,step=1)-
                              media_response(media=media,model_input,spd_range=spd_range,promo_range=promo_range,spd_new=media_spd)),
                 roi=atv*media_response(media=media,model_input,spd_range=spd_range,promo_range=promo_range,spd_new=media_spd)/media_spd)
    }


    result_all<-rbind(result_all,result)
  }
  return(result_all)
}


