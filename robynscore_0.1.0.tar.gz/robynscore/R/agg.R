
#' Media Summary w/o organic section for 3 models agg
#'
#' @param media_need
#' @param new_spd
#' @param model_1
#' @param model_2
#' @param model_3
#' @param spd_range
#' @param promo_range
#'
#' @return
#' @export
#'
#' @examples
media_summary_agg <- function(media_need,model_1,model_2,model_3,spd_range,promo_range,new_spd=NA){

  df_1<-media_summary(media_need,model_1,new_spd=new_spd,
                       spd_range=spd_range,
                       promo_range = promo_range)
  df_2<-media_summary(media_need,model_2,new_spd=new_spd,
                      spd_range=spd_range,
                      promo_range = promo_range)
  df_3<-media_summary(media_need,model_3,new_spd=new_spd,
                      spd_range=spd_range,
                      promo_range = promo_range)

  digital_df<-rbind(df_1,df_2,df_3)

  digital_df<-digital_df %>% group_by(media_group,media) %>%summarise(
    response=sum(response),spd=max(spd),
    roi=sum(response)/max(spd),roi.m=sum(roi.m)
  )

  digital_df$contri<-digital_df$response/sum(digital_df$response)
  digital_df$spd_pct<-digital_df$spd/sum(digital_df$spd)

  digital_df<-digital_df[,c("media","response","spd","contri","spd_pct","roi.m","roi")]
  return(digital_df)

}




#' media response for 3 models agg
#'
#' @param media
#' @param model_1
#' @param model_2
#' @param model_3
#' @param spd_range
#' @param promo_range
#' @param step
#' @param spd_new
#'
#' @return
#' @export
#'
#' @examples
media_response_agg<-function (media,model_1,model_2,model_3,spd_range=NA,promo_range=NA, step = 0,spd_new=NA){
  media_response(media=media,model_input=model_1,spd_range=spd_range,promo_range=promo_range, step = step,spd_new=spd_new)+
    media_response(media=media,model_input=model_2,spd_range=spd_range,promo_range=promo_range, step = step,spd_new=spd_new)+
    media_response(media=media,model_input=model_3,spd_range=spd_range,promo_range=promo_range, step = step,spd_new=spd_new)
}

#' media response change by step for 3 models agg
#'
#' @param media
#' @param model_1
#' @param model_2
#' @param model_3
#' @param spd_range
#' @param promo_range
#' @param step
#' @param spd_new
#'
#' @return
#' @export
#'
#' @examples
change.f.media_agg<-function(media,model_1,model_2,model_3,spd_range=NA,promo_range=NA, step = 1,spd_new=NA){
  change.f.media(media=media,model_input=model_1,spd_range=spd_range,promo_range=promo_range, step = step,spd_new=spd_new)+
    change.f.media(media=media,model_input=model_2,spd_range=spd_range,promo_range=promo_range, step = step,spd_new=spd_new)+
    change.f.media(media=media,model_input=model_3,spd_range=spd_range,promo_range=promo_range, step = step,spd_new=spd_new)
}




#' Budget allocation with unchanged ttl spd for 3 model agg
#'
#' @param media_need
#' @param model_1
#' @param model_2
#' @param model_3
#' @param old_spd
#' @param spd_range
#' @param promo_range
#' @param high_ratio Numeric or Vector same order as media_need
#' @param low_ratio Numeric or Vector same order as media_need
#'
#' @return
#' @export
#'
#' @examples
budget_spd_unchange_agg<-function(media_need,model_1,model_2,model_3,
                              old_spd=NA,spd_range,promo_range,atv=NA,
                              high_ratio=1.15,low_ratio=0.85){

  if(is.na(atv)){
    atv <- atv_cal(model_1,promo_range)
  }

  if(is.na(old_spd[1])){
    old_spd <- foreach(media = media_need, .combine = 'c') %do% {
      nv(max(media_result_all(media=media,model_1,spd_range,promo_range)$spd,
             media_result_all(media=media,model_2,spd_range,promo_range)$spd,
             media_result_all(media=media,model_3,spd_range,promo_range)$spd),media)
    }
  }
  spd_ttl<-sum(old_spd);spd_ttl

  spd_high<-old_spd

  spd_high<- high_ratio * spd_high

  spd_low<-old_spd

  spd_low<-low_ratio * spd_low
  x0<-old_spd


  np_orig<-sum(mapply(media_response_agg,
                      media=media_need,
                      model_1=rep(list(model_1),length(media_need)),
                      model_2=rep(list(model_2),length(media_need)),
                      model_3=rep(list(model_3),length(media_need)),
                      spd_range = rep(list(spd_range),length(media_need)),
                      promo_range =rep(list(promo_range),length(media_need)),
                      spd_new=x0))

  np<-np_orig

  cat(np[length(np)],"\n")

  steps<-c(100000,10000,1000,100,10,1,0.1,0.01,0.001,0.0001,0.00001)
  for(step in steps){
    for(i in 1:1000){
      jia<-mapply(change.f.media_agg,
                  media=media_need,
                  model_1=rep(list(model_1),length(media_need)),
                  model_2=rep(list(model_2),length(media_need)),
                  model_3=rep(list(model_3),length(media_need)),
                  spd_range =rep(list(spd_range),length(media_need)),
                  promo_range =rep(list(promo_range),length(media_need)),
                  step=change.f(x0,step,spd_high,spd_low),spd_new=x0)
      jian<-mapply(change.f.media_agg,
                   media=media_need,
                   model_1=rep(list(model_1),length(media_need)),
                   model_2=rep(list(model_2),length(media_need)),
                   model_3=rep(list(model_3),length(media_need)),
                   spd_range =rep(list(spd_range),length(media_need)),
                   promo_range =rep(list(promo_range),length(media_need)),
                   step=change.f(x0,-step,spd_high,spd_low),spd_new=x0)


      c_n<-min(length(jia[jia>0]),length(jian[jian<0]))

      criteria<-sort(jia[jia>0],decreasing = T)[1:c_n]+sort(jian[jian<0],decreasing = T)[1:c_n]
      crit_n<-sum(criteria>0.0001)
      if(names(jia[jia>0])[jia[jia>0]==max(jia[jia>0])]==names(jian[jian<0])[jian[jian<0]==max(jian[jian<0])]){
        crit_n<-0
      }

      if(crit_n>0){

        x0[which(jia>0)[order(jia[jia>0],decreasing=T)]][1:crit_n]<- x0[which(jia>0)[order(jia[jia>0],decreasing=T)]][1:crit_n]+step
        x0[which(jian<0)[order(jian[jian<0],decreasing=T)]][1:crit_n]<- x0[which(jian<0)[order(jian[jian<0],decreasing=T)]][1:crit_n]-step



        np<-c(np,sum(mapply(media_response_agg,
                            media=media_need,
                            model_1=rep(list(model_1),length(media_need)),
                            model_2=rep(list(model_2),length(media_need)),
                            model_3=rep(list(model_3),length(media_need)),
                            spd_range =rep(list(spd_range),length(media_need)),
                            promo_range =rep(list(promo_range),length(media_need)),
                            spd_new=x0)))
        cat("step ",step,"no.",i,"new NP: ",np[length(np)],"spd unchanged: ",round(sum(x0)-spd_ttl,0)==0,"\n")

      } else{
        cat("step ",step,":succeed!")
        break
      }

    }
  }

  result<-list(new_spd=x0,
               new_np=np,
               old_spd=old_spd,
               old_np=np_orig)

  return(result)

}


#' Budget allocation for a set target for 3 model agg
#'
#' @param media_need
#' @param model_1
#' @param model_2
#' @param model_3
#' @param tgt
#' @param old_spd
#' @param spd_range
#' @param promo_range
#' @param high_ratio
#' @param low_ratio
#'
#' @return
#' @export
#'
#' @examples
budget_spd_tgt_agg<-function(media_need,model_1,model_2,model_3,tgt,
                         old_spd=NA,spd_range,promo_range,atv=NA,
                         high_ratio=2,low_ratio=1){

  if(is.na(atv)){
    atv <- atv_cal(model_1,promo_range)
  }

  if(is.na(old_spd[1])){
    old_spd <- foreach(media = media_need, .combine = 'c') %do% {
      nv(max(media_result_all(media=media,model_1,spd_range,promo_range)$spd,
             media_result_all(media=media,model_2,spd_range,promo_range)$spd,
             media_result_all(media=media,model_3,spd_range,promo_range)$spd),media)
    }
  }
  spd_ttl<-sum(old_spd);spd_ttl

  spd_high<-old_spd

  spd_high<- high_ratio * spd_high

  spd_low<-old_spd

  spd_low<-low_ratio * spd_low
  x0<-old_spd


  np_orig<-sum(mapply(media_response_agg,
                      media=media_need,
                      model_1=rep(list(model_1),length(media_need)),
                      model_2=rep(list(model_2),length(media_need)),
                      model_3=rep(list(model_3),length(media_need)),
                      promo_range =rep(list(promo_range),length(media_need)),
                      spd_new=x0))

  np<-np_orig

  cat(np[length(np)],"\n")

  steps<-c(100000,10000,1000,100,10,1)
  for(step in steps){
    for(i in 1:1000){
      jia<-mapply(change.f.media_agg,
                  media=media_need,
                  model_1=rep(list(model_1),length(media_need)),
                  model_2=rep(list(model_2),length(media_need)),
                  model_3=rep(list(model_3),length(media_need)),
                  promo_range =rep(list(promo_range),length(media_need)),
                  step=change.f(x0,step,spd_high,spd_low),spd_new=x0)

      c_n<-length(jia[jia>0])
      if(c_n==0){break}

      x1<-x0
      x1[jia==max(jia)]<-x1[jia==max(jia)]+step
      np<-c(np,sum(mapply(media_response_agg,
                          media=media_need,
                          model_1=rep(list(model_1),length(media_need)),
                          model_2=rep(list(model_2),length(media_need)),
                          model_3=rep(list(model_3),length(media_need)),
                          promo_range =rep(list(promo_range),length(media_need)),
                          spd_new=x1)))

      if(np[length(np)]>tgt){
        cat("step ",step,":succeed!")
        break} else
        {
          x0[jia==max(jia)]<-x0[jia==max(jia)]+step
          cat("step ",step,"no.",i,"new NP: ",np[length(np)],"spd changed: ",round(sum(x0)-spd_ttl,0),"\n")
        }

    }}


  result<-list(new_spd=x0,
               new_np=np,
               old_spd=old_spd,
               old_np=np_orig)

  return(result)

}
