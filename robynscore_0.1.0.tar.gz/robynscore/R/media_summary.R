#' Rebuild Robyn prophet components
#'
#' @param model_input List. with Robyn hyper parameters and input, see demo.R for details
#'
#' @return
#' @export
#'
#' @examples
organic_df<-function(model_input){
  df<-subset(model_input$dt_orig,select=c(model_input$date_var,model_input$dep_var))
  names(df)<-c("ds","y")

  prophet_vars <- model_input$prophet_var
  use_trend <- any(str_detect("trend", prophet_vars))
  use_season <- any(str_detect("season", prophet_vars))
  use_weekday <- any(str_detect("weekday", prophet_vars))
  use_holiday <- any(str_detect("holiday", prophet_vars))
  holidays <- model_input$holidays

  prophet_range<-c(model_input$prophet_start,model_input$prophet_end)

  modelRecurrance <- prophet(
    df = subset(df,ds>=prophet_range[1] & ds<=prophet_range[2]),
    holidays = if (use_holiday) holidays,
    yearly.seasonality = use_season,
    weekly.seasonality = use_weekday,
    daily.seasonality = FALSE
  )

  forecastRecurrance <- predict(modelRecurrance, df)

  coefs<-model_input$coefs
  df$organic <- 0
  if (use_trend) {
    df$trend <- forecastRecurrance$trend * coefs["trend"]
    df$organic <- df$organic+df$trend
  }
  if (use_season) {
    df$season <- forecastRecurrance$yearly* coefs["season"]
    df$organic <- df$organic+df$season
  }
  if (use_weekday) {
    df$weekday <- forecastRecurrance$weekly* coefs["weekday"]
    df$organic <- df$organic+df$weekday
  }
  if (use_holiday) {
    df$holiday <- forecastRecurrance$holidays* coefs["holiday"]
    df$organic <- df$organic+df$holiday
  }

  if(sum(grepl("(Intercept)",names(coefs)))>0) {
    df$intercept <- coefs["(Intercept)"]
    df$organic <- df$organic+df$intercept
  }

  df$organic_pct <- df$organic/df$y

  return(df)
}

#' calculate summary for channel group if exists
#'
#' @param media_sum data.frame from media_summary
#'
#' @return
#' @export
#'
#' @examples
channel_group_summary <- function(media_sum){
  result<-media_sum %>% group_by(media_group) %>% summarise(response=sum(response),
                                                            spd_sum=sum(spd),
                                                            contri=sum(contri),
                                                            spd_pct=sum(spd_pct),
                                                            roi.m=weighted.mean(roi.m,spd,na.rm=T),
                                                            roi=mean(atv)*sum(response)/sum(spd),
                                                            atv=mean(atv))
  return(result)

}

#' Calculate atv if gmv_var different from dep_var
#'
#' @param model_input
#' @param promo_range
#'
#' @return
#' @export
#'
#' @examples
atv_cal<-function(model_input,promo_range=NA){
  if(is.null(model_input$gmv_var)){atv<-1}
  else{
    if(is.na(promo_range[1])){
      promo_range<-c(model_input$model_start,model_input$model_end)
    }
    dt_orig<-model_input$dt_orig
    ds <- as.Date(unlist(subset(dt_orig,select=model_input$date_var)),origin=as.Date("1970-01-01"))
    promo_window <- time_window(ds,promo_range)
    promo_gmv <- sum(unlist(subset(dt_orig, select = model_input$gmv_var))[promo_window])
    promo_dep <- sum(unlist(subset(dt_orig, select = model_input$dep_var))[promo_window])
    atv <- promo_gmv/promo_dep}
  return(atv)
}

#' Summary of Media contri, roi, mroi
#'
#' @param media_need
#' @param model_input
#' @param spd_range
#' @param promo_range
#' @param df_orga data.frame. must have ds organic
#'
#' @return
#' @export
#'
#' @examples
media_summary <- function(media_need,model_input,new_spd=NA,spd_range=NA,promo_range=NA,df_orga=NA,atv=NA){
  if(is.na(promo_range[1])){
    promo_range<-c(model_input$model_start,model_input$model_end)
  }

  if(is.na(spd_range[1])){
    spd_range<-promo_range
  }

  if(is.na(atv)){
    atv <- atv_cal(model_input,promo_range)
  }

  if(is.na(new_spd[1])){
    new_spd <- foreach(media = media_need, .combine = 'c') %do% {
      nv(media_result_all(media=media,model_input=model_input,spd_range=spd_range,promo_range=promo_range)$spd,media)
    }
  }


  result<-foreach(media = media_need, .combine='rbind')%do%{
    data.frame(media=media,
               spd=media_result_all(media=media,model_input=model_input,spd_range=spd_range,promo_range=promo_range,spd_new = new_spd[media])$spd,
               response=media_response(media=media,model_input=model_input,spd_range=spd_range,promo_range=promo_range,spd_new = new_spd[media]),
               roi.m=atv*change.f.media(media=media,model_input=model_input,spd_range=spd_range,promo_range=promo_range,spd_new = new_spd[media],step=1),
               atv=atv)

  }
  result$spd<-as.numeric(result$spd)
  result$response<-as.numeric(result$response)
  result$roi.m<-as.numeric(result$roi.m)
  result$roi=atv*(result$response/result$spd)



  if(!is.na(df_orga)[1]){
    ds <- as.Date(df_orga$ds)
    promo_window <- time_window(ds,promo_range)
    orga<-sum(df_orga$organic[promo_window])
    orga_line<-data.frame(media="organic",spd=0,response=orga,roi.m=NA,roi=NA,atv=NA)
    result<-rbind(result,orga_line)
  }

  if(!is.null(model_input$context_vars)){
    dt_orig<-model_input$dt_orig
    ds <- as.Date(unlist(subset(dt_orig,select=model_input$date_var)),origin=as.Date("1970-01-01"))
    promo_window <- time_window(ds,promo_range)

    context_vars<-model_input$context_vars
    coefs<-model_input$coefs

    context<-c()
    for(i in context_vars){
      spd_orig<-dt_orig[,i]
      spd_sum<-sum(spd_orig[promo_window])
      context<-c(context,spd_sum)
    }

    context <- context * coefs[context_vars]
    context_line<-data.frame(media=model_input$context_vars,spd=0,response=context,roi.m=NA,roi=NA,atv=NA)
    result<-rbind(result,context_line)
  }

  result$spd_pct<-result$spd/sum(result$spd)
  result$contri<-result$response/sum(result$response)

  if(is.null(model_input$channel_group)){
    result<-result[,c("media","response","spd","contri","spd_pct","roi.m","roi","atv")]
    result<-result %>% arrange(-spd)
  } else{
    media_group<-model_input$channel_group
    result<-merge(result,media_group,by="media",all.x=T)
    result<-result[,c("media_group","media","response","spd","contri","spd_pct","roi.m","roi","atv")]
    result<-result %>% arrange(media_group,-spd)
  }

  return(result)
}
