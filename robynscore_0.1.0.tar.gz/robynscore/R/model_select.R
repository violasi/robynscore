#' Get Robyn result list for other robynscore functions
#'
#' @param robyn_model List. direct robyn output
#' @param selectedID String. solID
#'
#' @return
#' @export
#'
#' @examples
model_input<-function(robyn_model,selectedID){
  roi_m_all<-data.frame()

  model<- list(
    dt_orig = robyn_model$InputCollect$dt_input, # input data
    media_all = robyn_model$InputCollect$all_media, # media names
    date_var = robyn_model$InputCollect$date_var, # date column
    dep_var = robyn_model$InputCollect$dep_var, # y column
    adstock = robyn_model$InputCollect$adstock, # geometric, weibull_cdf or weibull_pdf
    # alphas = alphas, # named vector _alphas
    # gammas = gammas, # named vector _gammas
    # thetas = thetas, # named vector _thetas,if geometric
    # coefs = coefs_vector, # named vector
    model_start = robyn_model$InputCollect$window_start,
    model_end = robyn_model$InputCollect$window_end,
    context_vars=robyn_model$InputCollect$context_vars,
    holidays = robyn_model$InputCollect$dt_holidays,
    prophet_var = robyn_model$InputCollect$prophet_vars,
    prophet_start = robyn_model$InputCollect$window_start,#mark:may need to change to dt_orig_start later
    prophet_end = robyn_model$InputCollect$window_end
  )

    hyperPar <- unlist(subset(robyn_model$OutputCollect$resultHypParam,solID==selectedID))
    model$thetas <- hyperPar[grepl("_thetas", names(hyperPar))]
    model$alphas<-hyperPar[grepl("_alphas", names(hyperPar))]
    model$gammas<-hyperPar[grepl("_gammas", names(hyperPar))]
    # model$scales<-hyperPar[grepl("_scales", names(hyperPar))]
    # model$shapes<-hyperPar[grepl("_shapes", names(hyperPar))]


    coefs <- robyn_model$OutputCollect$xDecompAgg$coef[robyn_model$OutputCollect$xDecompAgg$solID==selectedID]
    names(coefs) <-robyn_model$OutputCollect$xDecompAgg$rn[robyn_model$OutputCollect$xDecompAgg$solID==selectedID]

    model$coefs<-coefs
    return(model)
}



#' Create media summary dataframes for all selected solID
#'
#' @param robyn_model
#' @param selected
#'
#' @return
#' @export
#'
#' @examples
model_select<-function(robyn_model,selected,campaign=NA){
  roi_m_all<-data.frame()

  model<- list(
    dt_orig = robyn_model$InputCollect$dt_input, # input data
    media_all = robyn_model$InputCollect$all_media, # media names
    date_var = robyn_model$InputCollect$date_var, # date column
    dep_var = robyn_model$InputCollect$dep_var, # y column
    context_vars=robyn_model$InputCollect$context_vars,
    adstock = robyn_model$InputCollect$adstock, # geometric, weibull_cdf or weibull_pdf
    # alphas = alphas, # named vector _alphas
    # gammas = gammas, # named vector _gammas
    # thetas = thetas, # named vector _thetas,if geometric
    # coefs = coefs_vector, # named vector
    model_start = robyn_model$InputCollect$window_start,
    model_end = robyn_model$InputCollect$window_end,
    holidays = robyn_model$InputCollect$dt_holidays,
    prophet_var = robyn_model$InputCollect$prophet_vars,
    prophet_start = robyn_model$InputCollect$window_start,#mark:may need to change to dt_orig_start later
    prophet_end = robyn_model$InputCollect$window_end
  )



  for (selectedID in selected){
    hyperPar <- unlist(subset(robyn_model$OutputCollect$resultHypParam,solID==selectedID))
    model$thetas <- hyperPar[grepl("_thetas", names(hyperPar))]
    model$alphas<-hyperPar[grepl("_alphas", names(hyperPar))]
    model$gammas<-hyperPar[grepl("_gammas", names(hyperPar))]
    # model$scales<-hyperPar[grepl("_scales", names(hyperPar))]
    # model$shapes<-hyperPar[grepl("_shapes", names(hyperPar))]


    coefs <- robyn_model$OutputCollect$xDecompAgg$coef[robyn_model$OutputCollect$xDecompAgg$solID==selectedID]
    names(coefs) <-robyn_model$OutputCollect$xDecompAgg$rn[robyn_model$OutputCollect$xDecompAgg$solID==selectedID]

    model$coefs<-coefs

    if(is.null(model$prophet_var)){
      if(is.na(campaign[1])){
        roi.m<-media_summary(media_need,model)
      } else{
        roi.m<-media_summary(media_need,model,
                             promo_range = campaign)
      }
    } else{
      df <- organic_df(model)

      if(is.na(campaign[1])){
        roi.m<-media_summary(media_need,model,df_orga=df)
      } else{
        roi.m<-media_summary(media_need,model,df_orga=df,
                             promo_range = campaign)
      }

    }





    roi.m$solID<-selectedID

    roi_m_all<-rbind(roi_m_all,roi.m)

  }

  return(roi_m_all)
}

