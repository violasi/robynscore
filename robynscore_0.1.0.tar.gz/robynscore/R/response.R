#' The single media mroi function
#'
#' The \code {change.f.media()} function calculate a media's mroi during promo_range with (un)changed spend of a spd_range
#' @param media Character. name of media you want to deep dive
#' @param model_input List. with Robyn hyper parameters and input, see demo.R for details
#' @param spd_range Date vector. c(spd_change_start_date, spd_change_end_date), the time range you want to change spend, if NA the model window
#' @param promo_range Date vector. c(promo_start_date, promo_end_date), the time range you want to zoom in, if NA the model window
#' @param step Integer. Change value of spend for a specified spd_range
#' @param spd_new Numeric. TTL spend for a specified spd_range, no spd change if NA
#'
#' @return Numeric. marginal roi
#' @export
#'
#' @examples
#'  \dontrun{
#' change.f.media(media = "facebook_I",
#' model_input = robyn_model,
#' promo_range = campaign)
#' }
change.f.media<-function(media,model_input,spd_range=NA,promo_range=NA, step = 1,spd_new=NA)
{

  media_response(media=media,model_input=model_input,spd_range=spd_range,promo_range=promo_range,spd_new=spd_new,step=step)-
    media_response(media=media,model_input=model_input,spd_range=spd_range,promo_range=promo_range,spd_new=spd_new,step=0)
}




#' The single media spd function
#'
#' The \code {media_spd()} function calculate a media's spend during promo_range with (un)changed spend of a spd_range
#' @param media Character. name of media you want to deep dive
#' @param model_input List. with Robyn hyper parameters and input, see demo.R for details
#' @param spd_range Date vector. c(spd_change_start_date, spd_change_end_date), the time range you want to change spend, if NA the model window
#' @param promo_range Date vector. c(promo_start_date, promo_end_date), the time range you want to zoom in, if NA the model window
#' @param step Integer. Change value of spend for a specified spd_range
#' @param spd_new Numeric. TTL spend for a specified spd_range, no spd change if NA
#'
#' @return Numeric. spend
#' @export
#'
#' @examples
#'  \dontrun{
#' media_spd(media = "facebook_I",
#' model_input = robyn_model,
#' promo_range = campaign)
#' }
media_spd<-function(media,model_input,spd_range=NA,promo_range=NA, step = 1,spd_new=NA)
{

  result<-media_result_all(media=media,model_input=model_input,spd_range=spd_range,
                           promo_range=promo_range,step=step,spd_new=spd_new)
  return(result$spd)
}


#' The single media response function
#'
#' The \code {media_response()} function calculate a media's response during promo_range with (un)changed spend of a spd_range
#' @param media Character. name of media you want to deep dive
#' @param model_input List. with Robyn hyper parameters and input, see demo.R for details
#' @param spd_range Date vector. c(spd_change_start_date, spd_change_end_date), the time range you want to change spend, if NA the model window
#' @param promo_range Date vector. c(promo_start_date, promo_end_date), the time range you want to zoom in, if NA the model window
#' @param step Integer. Change value of spend for a specified spd_range
#' @param spd_new Numeric. TTL spend for a specified spd_range, no spd change if NA
#'
#' @return Numeric. media response
#' @export
#'
#' @examples
#' \dontrun{
#' media_response(media = "facebook_I",
#' model_input = robyn_model,
#' promo_range = campaign)
#' }
media_response <- function (media,model_input,spd_range=NA,promo_range=NA, step = 0,spd_new=NA)
{
  result<-media_result_all(media=media,model_input=model_input,spd_range=spd_range,
                           promo_range=promo_range,step=step,spd_new=spd_new)
  return(result$response)

}

#' The single media daily response function
#'
#' The \code {media_response()} function calculate a media's response during promo_range with (un)changed spend of a spd_range
#' @param media Character. name of media you want to deep dive
#' @param model_input List. with Robyn hyper parameters and input, see demo.R for details
#' @param spd_range Date vector. c(spd_change_start_date, spd_change_end_date), the time range you want to change spend, if NA the model window
#' @param promo_range Date vector. c(promo_start_date, promo_end_date), the time range you want to zoom in, if NA the model window
#' @param step Integer. Change value of spend for a specified spd_range
#' @param spd_new Numeric. TTL spend for a specified spd_range, no spd change if NA
#'
#' @return Numeric. media response
#' @export
#'
#' @examples
#' \dontrun{
#' media_response(media = "facebook_I",
#' model_input = robyn_model,
#' promo_range = campaign)
#' }
media_response_daily <- function (media,model_input,spd_range=NA,promo_range=NA, step = 0,spd_new=NA)
{
  result<-media_result_all(media=media,model_input=model_input,spd_range=spd_range,
                           promo_range=promo_range,step=step,spd_new=spd_new)
  return(result$response_daily)

}

#' The Single Media Deep Dive Function
#'
#' The \code {media_result_all()} function deep dive everything you want to know about a single media based on Robyn hyper parameters
#' @param media Character. name of media you want to deep dive
#' @param model_input List. with Robyn hyper parameters and input, see demo.R for details
#' @param spd_range Date vector. c(spd_change_start_date, spd_change_end_date), the time range you want to change spend, if NA the model window
#' @param promo_range Date vector. c(promo_start_date, promo_end_date), the time range you want to zoom in, if NA the model window
#' @param step Integer. Change value of spend for a specified spd_range
#' @param spd_new Numeric. TTL spend for a specified spd_range, no spd change if NA
#'
#' @return list. ttl response, spd, gammatrans, spd_daily, spd_adstock, spd_sat, daily_response
#' @export
#'
#' @examples
#' \dontrun{
#' media_deep_dive<-media_result_all(
#' media = "facebook_I",
#' model_input = robyn_model)
#' }
media_result_all <- function (media,model_input,spd_range=NA,promo_range=NA, step = 0,spd_new=NA)
{

  alphas <- model_input$alphas
  gammas <- model_input$gammas
  dt_orig <- model_input$dt_orig
  ds <- as.Date(unlist(subset(dt_orig,select=model_input$date_var)),origin=as.Date("1970-01-01"))
  model_window <- ds>=model_input$model_start & ds<= model_input$model_end
  adstock<-model_input$adstock
  coefs<-model_input$coefs

  if(is.na(promo_range[1])){
    promo_range<-c(model_input$model_start,model_input$model_end)
  }

  if(is.na(spd_range[1])){
    spd_range<-promo_range
  }
  spd_window <- ds>=spd_range[1] & ds<=spd_range[2]
  promo_window <- ds>=promo_range[1] & ds<=promo_range[2]


  if(media %in% model_input$media_all){
    model_spd <- unlist(subset(dt_orig, select = media))[model_window]
    orig_spd <- unlist(subset(dt_orig, select = media))
    spd <- sum(orig_spd[spd_window])
    if(is.na(spd_new)){spd_new <- spd + step} else {spd_new <- spd_new + step}
    if(spd_new==0|spd==0){
      lambda<-1
    }else
    {lambda <- spd_new/spd}

    if(spd==0){
      orig_spd[spd_window] <- rep(spd_new/sum(spd_window),sum(spd_window))
    } else{
      orig_spd[spd_window] <- lambda * orig_spd[spd_window]
    }

    if (adstock == "geometric") {
      thetas <- model_input$thetas
      theta <- as.numeric(thetas[grepl(media, names(thetas)) &
                                   nchar(names(thetas)) == nchar(media) + nchar("_thetas")])
      model_spd_adstock <- unlist(adstock_geometric(model_spd,
                                                    theta)$x_decayed)
      spd_adstock <- unlist(adstock_geometric(orig_spd, theta)$x_decayed)
    }else if (adstock == "weibull_cdf") {
      shapes <- model_input$shapes
      scales <- model_input$scales
      shape <- as.numeric(shapes[grepl(media, names(shapes)) &
                                   nchar(names(shapes)) == nchar(media) + nchar("_shapes")])
      scale <- as.numeric(scales[grepl(media, names(scales)) &
                                   nchar(names(scales)) == nchar(media) + nchar("_scales")])
      model_spd_adstock <- unlist(adstock_weibull(x = model_spd,
                                                  shape = shape, scale = scale, windlen = sum(model_window),
                                                  type = "cdf")$x_decayed)
      spd_adstock <- unlist(adstock_weibull(x = orig_spd, shape = shape,
                                            scale = scale, windlen = sum(model_window), type = "cdf")$x_decayed)
    }else if (adstock == "weibull_pdf") {
      shapes <- model_input$shapes
      scales <- model_input$scales
      shape <- as.numeric(shapes[grepl(media, names(shapes)) &
                                   nchar(names(shapes)) == nchar(media) + nchar("_shapes")])
      scale <- as.numeric(scales[grepl(media, names(scales)) &
                                   nchar(names(scales)) == nchar(media) + nchar("_scales")])
      model_spd_adstock <- unlist(adstock_weibull(x = model_spd,
                                                  shape = shape, scale = scale, windlen = sum(model_window),
                                                  type = "pdf")$x_decayed)
      spd_adstock <- unlist(adstock_weibull(x = orig_spd, shape = shape,
                                            scale = scale, windlen = sum(model_window), type = "pdf")$x_decayed)
    }else {
      break
      print("adstock parameter must be geometric, weibull_cdf or weibull_pdf")
    }
    gamma <- as.numeric(gammas[grepl(media, names(gammas)) &
                                 nchar(names(gammas)) == nchar(media) + nchar("_gammas")])
    gammaTrans <- round(quantile(seq(range(model_spd_adstock)[1],
                                     range(model_spd_adstock)[2], length.out = 100), gamma),
                        4)
    alpha <- as.numeric(alphas[grepl(media, names(alphas)) &
                                 nchar(names(alphas)) == nchar(media) + nchar("_alphas")])
    spend_sat <- spd_adstock^alpha/(spd_adstock^alpha + gammaTrans^alpha)
    coef <- as.numeric(coefs[grepl(media, names(coefs)) & nchar(names(coefs)) ==
                               nchar(media)])
    response <- spend_sat * coef
    result<-list(response=sum(response[promo_window]),
                 spd=sum(orig_spd[spd_window]),
                 gammatrans=gammaTrans,
                 spd_daily=orig_spd,
                 spd_adstock=spd_adstock,
                 spd_sat=spend_sat,
                 response_daily=response)
  } else{result<-list(response=0,
                      spd=0,
                      gammatrans=NA,
                      spd_daily=rep(0,nrow(dt_orig)),
                      spd_adstock=rep(0,nrow(dt_orig)),
                      spd_sat=rep(0,nrow(dt_orig)),
                      response_daily=rep(0,nrow(dt_orig)))}
  return(result)
}
