library(robynscore)
library(Robyn)
library(doParallel)
library(foreach)
library(stringr)

library(data.table)
library(ggplot2)
library(prophet)
library(lubridate)
library(dplyr)
library(openxlsx)
library(caroline)

# Save robyn result after running robyn
doc<-"Robyn_202303081516_init"
script_path <- "D:/loreal/digitalMMM/version2/JD主模型/"
#dt_orig<-fread(paste0(script_path,"tmall_insite.csv"))
dt_orig<-read.xlsx(paste0(script_path,"jd_20230306rawdata.xlsx"),
                   sheet="Sheet1",detectDates = T)
resultHypParam<-fread(paste0(script_path,doc,"/all_hyperparameters.csv"))
xDecompAgg<-fread(paste0(script_path,doc,"/all_aggregated.csv"))
OutputCollect<-list(resultHypParam=resultHypParam,xDecompAgg=xDecompAgg)
unique(xDecompAgg$rn)

selected_in_model<-c("jd_insite_ttl" ,  "jd_others" ,     
                      "Live_cost"  ,     "social_RTB" ,     "display_spd_ttl",
                     "otv_spd"     ,    "dy_ttl")
# selected_in_model<-c("bilibili_social_spd" ,"red_social_spd"  ,    "tiktok_rtb_spd"   ,  
#                       "tiktok_social_spd" ,  "wechat_social_spd"  , "weibo_social_spd")
holiday<-fread(paste0(script_path,"dt_mod.csv"))
# holiday<-subset(holiday,holiday>0,select=c("ds","holiday"))
# holiday$country<-"CN"
# 
# holiday$year<-year(holiday$ds)
#holiday$holiday<-as.character(round(holiday$holiday,1))
InputCollect <- robyn_inputs(
  dt_input = dt_orig
  #,dt_holidays = holiday
  
  ### set variables
  
  ,date_var = "date" # Date format must be "2020-01-01"
  ,dep_var = "GMV" # change here
  ,dep_var_type = "conversion" # "revenue" or "conversion"
  
  #,prophet_vars = c("trend", "season", "holiday") # "trend","season", "weekday", "holiday"
  # are provided and case-sensitive. Recommended to at least keep Trend & Holidays
  #,prophet_signs = c("positive","positive", "positive") # c("default", "positive", and "negative").
  # Recommend as default.Must be same length as prophet_vars
  #,prophet_country = "CN"# only one country allowed once. Including national holidays
  # for 59 countries, whose list can be found on our github guide
  
  ,context_vars = c() # typically competitors, price &
  # promotion, temperature, unemployment rate etc
  ,context_signs = c() # c("default", " positive", and "negative"),
  # control the signs of coefficients for baseline variables
  
  ,paid_media_vars = selected_in_model
  # c("tv_S"	,"ooh_S",	"print_S"	,"facebook_I", "facebook_S","search_clicks_P"	,"search_S")
  # we recommend to use media exposure metrics like impressions, GRP etc for the model.
  # If not applicable, use spend instead
  ,paid_media_signs = rep("positive",length(selected_in_model))
  # c("default", "positive", and "negative"). must have same length as paid_media_vars.
  # Controls the signs of coefficients for media variables
  ,paid_media_spends = selected_in_model
  # spends must have same order and same length as paid_media_vars
  
  ,organic_vars = c()
  ,organic_signs = c() # must have same length as organic_vars
  
  ,factor_vars = c() # specify which variables in context_vars and
  # organic_vars are factorial
  
  ### set model parameters
  
  ## set cores for parallel computing
  ,cores = 14 # I am using 6 cores from 8 on my local machine. Use future::availableCores() to find out cores
  
  ## set rolling window start
  ,window_start = "2021-01-01"
  ,window_end = "2022-12-31"
  
  ## set model core features
  ,adstock = "geometric" # geometric, weibull_cdf or weibull_pdf. Both weibull adstocks are more flexible
  # due to the changing decay rate over time, as opposed to the fixed decay rate for geometric. weibull_pdf
  # allows also lagging effect. Yet weibull adstocks are two-parametric and thus take longer to run.
  ,iterations = 2000  # number of allowed iterations per trial. For the simulated dataset with 11 independent
  # variables, 2000 is recommended for Geometric adsttock, 4000 for weibull_cdf and 6000 for weibull_pdf.
  # The larger the dataset, the more iterations required to reach convergence.
  
  ,nevergrad_algo = "TwoPointsDE" # recommended algorithm for Nevergrad, the gradient-free
  # optimisation library https://facebookresearch.github.io/nevergrad/index.html
  ,trials = 5 # number of allowed iterations per trial. 5 is recommended without calibration,
  # 10 with calibration.
  
  # Time estimation: with geometric adstock, 2000 iterations * 5 trials
  # and 6 cores, it takes less than 1 hour. Both Weibull adstocks take up to twice as much time.
)

robyn_model<-list(
  InputCollect=InputCollect,
  OutputCollect=OutputCollect)



nrow(robyn_model$OutputCollect$resultHypParam) #20020
range(robyn_model$OutputCollect$xDecompAgg$rsq_train) #-0.01061536  0.89187736
range(robyn_model$OutputCollect$xDecompAgg$margin_roi_score)
hyp<-robyn_model$OutputCollect$resultHypParam




selected<-subset(hyp,rsq_train>=0.95) #AI智投需要是C curve，不能饱和
nrow(selected) #594

9985/20020
range(selected$rsq_train)
selected$solID[selected$rsq_train==max(selected$rsq_train)]
selected<-selected$solID #选定的要看marginal roi的模型ID存在selected
length(selected)

decomp<-robyn_model$OutputCollect$xDecompAgg
decomp_sub<-subset(decomp, select=c("solID","rn","xDecompPerc","spend_share","roi_total","rsq_train","decomp.rssd"),solID %in% selected)



# 只留所有coef都大于0的
decomp_sub$coef_0<-decomp_sub$xDecompPerc>0
media_need<-robyn_model$InputCollect$all_media
media_need
check_coef<-subset(decomp_sub,rn %in% media_need)
check_coef<-check_coef %>% group_by(solID) %>% summarise(coef_0=sum(coef_0)/length(media_need)) %>% filter(coef_0>0.4)

selected<-check_coef$solID[check_coef$coef_0>=1]
length(selected) #594
657/657

#只留organic在一定范围的
# orga<-subset(decomp_sub,rn %in% c("(Intercept)","holiday","season","trend") & solID %in% selected)
# orga<-orga %>% group_by(solID) %>% summarise(orga=sum(xDecompPerc))
# summary(orga$orga)
# selected<-orga$solID[orga$orga>=0.1 & orga$orga<=0.25]
# length(selected) #266
# 
# qc<-subset(decomp_sub,solID %in% selected & !rn %in% c("(Intercept)","holiday","season","trend"),select=c("solID","rn","xDecompPerc")) %>% 
#              group_by(rn) %>% summarise(ctbt_min=min(xDecompPerc),
#                                               ctbt_avg=mean(xDecompPerc),
#                                               ctbt_max=max(xDecompPerc),
#                                               ctbt_sd=sd(xDecompPerc))
# # 393/657

#只留roi排序taoke>live>insite>otv
decomp_sub<-subset(decomp, select=c("solID","rn","xDecompPerc","spend_share","roi_total","rsq_train","decomp.rssd"),solID %in% selected)

#decomp_sub<-subset(decomp_sub,rn %>% c("ai_smart_delivery","banner_spd","cjtj_spd",""))

# roi_order <- decomp_sub %>%
#   group_by(solID) %>% arrange(-roi_total) %>% mutate(roi_order=row_number())
# 
# roi_sd<-roi_order %>% group_by(solID) %>% summarise(sd=sd(roi_total,na.rm = T))
# qc<-subset(roi_order,solID=="1_131_1")
# table(roi_order$rn[roi_order$roi_order==1])
# table(roi_order$rn[roi_order$roi_order==2])
# table(roi_order$rn[roi_order$roi_order==3])
# 
# table(roi_order$rn[roi_order$roi_order==4])
# table(roi_order$rn[roi_order$roi_order==5])
# table(roi_order$rn[roi_order$roi_order==6])
# table(roi_order$rn[roi_order$roi_order==7])
# 
# roi_order %>% group_by(rn) %>% summarise(max(roi_total),min(roi_total),mean(roi_total))
# roi_order %>% group_by(rn) %>% summarise(max(xDecompPerc ),min(xDecompPerc ),mean(xDecompPerc))
# 
# selected_1<-roi_order$solID[roi_order$rn=="dy_insite" & roi_order$xDecompPerc<=0.03 ]
# selected_2<-roi_order$solID[roi_order$rn=="display_other_spd" & roi_order$roi_order >=5  ]
# selected_3<-roi_order$solID[roi_order$rn=="tiktok_display_spd" & roi_order$roi_order <=3 & roi_order$roi_total >=0.05 ]
# #selected_4<-roi_order$solID[roi_order$rn=="red_display_spd" & roi_order$roi_order <=3 & roi_order$roi_total >=0.05 ]
# 
# # selected_1<-roi_order$solID[roi_order$rn=="ai_smart_delivery" & roi_order$roi_total >=3  ]
# # selected_2<-roi_order$solID[roi_order$rn=="ztc_spd" & roi_order$roi_total >=3   ]
# # selected_3<-roi_order$solID[roi_order$rn=="red_social_spd" & roi_order$roi_total >=2]
# # selected_4<-roi_order$solID[roi_order$rn=="weibo_display_spd" & roi_order$roi_total>=2]
# # selected_5<-roi_order$solID[roi_order$rn=="tiktok_social_spd" & roi_order$roi_total>=2]
# #selected_6<-roi_order$solID[roi_order$rn=="display" & roi_order$roi_order %in% c(4,5)& roi_order$xDecompPerc>=0.08]
# #selected_7<-roi_order$solID[roi_order$rn=="display_other_spd" & roi_order$roi_order==6]
# 
# # total_order<-selected_2  %>% intersect(selected_3) %>%
# #   intersect(selected_4) %>% intersect(selected_5) %>% intersect(selected_6) %>% intersect(selected_7)
# #
# # selected<-total_order%>% intersect(selected)
# selected<-selected_1  %>% intersect(selected_2)%>% intersect(selected_3)
# length(selected) #26

selected<-selected_1
selected<-c("1_9_9","3_32_7")
## 看618的roi和mroi排序
media_need<-robyn_model$InputCollect$paid_media_vars
campaign<-c(as.Date("2022-01-01"),as.Date("2022-12-31"))
#campaign<-c(as.Date("2021-01-01"),as.Date("2021-12-31"))
campaign<-c(as.Date("2022-10-24"),as.Date("2022-11-11"))
campaign<-c(as.Date("2022-05-26"),as.Date("2022-06-20"))
campaign<-c(as.Date("2022-02-27"),as.Date("2022-03-08"))
campaign<-c(as.Date("2023-02-27"),as.Date("2023-03-08"))

roi_m_all<-model_select(robyn_model,selected,campaign)

roi_order <- roi_m_all %>%
  group_by(solID) %>% arrange(-roi.m) %>% mutate(roi_order=row_number())
roi_order<-merge(roi_order,hyp[,c("solID","rsq_train")],all.x=T)


write.csv(roi_order,file="qc.csv")
roi_order$solID[roi_order$rsq_train==max(roi_order$rsq_train)]
#######################

roi_m_range<-roi_m_all %>% group_by(media) %>%
  summarise(mroi_min=min(roi.m),mroi_max=max(roi.m),mroi_mean=mean(roi.m),mroi_sd=sd(roi.m)) %>% arrange(-mroi_mean)

roi_range<-roi_m_all %>% group_by(media) %>%
  summarise(roi_min=min(roi),roi_max=max(roi),roi_mean=mean(roi),roi_sd=sd(roi)) %>% arrange(-roi_mean)

qc<-roi_m_all %>% 
  group_by(media) %>% summarise(ctbt_min=min(contri),
                             ctbt_avg=mean(contri),
                             ctbt_max=max(contri),
                             ctbt_sd=sd(contri))

fwrite(qc,file="qc.csv")

qc<-roi_m_all %>% 
  group_by(media) %>% summarise(roi.m_min=min(roi.m),
                                roi.m_avg=mean(roi.m),
                                roi.m_max=max(roi.m),
                                roi.m_sd=sd(roi.m))

fwrite(qc,file="qc.csv")
# 393/657


write.csv(roi_order,file="qc.csv")
#write.csv(roi_range,file="qc.csv")



# 设618 roi排序的筛选条件，比如站内直钻超AI智投最好比较强
selected_1<-roi_order$solID[roi_order$media=="live_ljq_spd" & roi_order$roi_order<=1 & roi_order$roi.m>3.37] #&

selected_2<-roi_order$solID[roi_order$media=="tiktok_social_spd" & roi_order$roi_order <=3]

selected_3<-roi_order$solID[roi_order$media=="tiktok_rtb_spd" & roi_order$roi_order <=2]

total_order<-selected_1  %>% intersect(selected_2) %>% intersect(selected_3) #%>% intersect(selected_4)%>% intersect(selected_5)

sd<-roi_order %>% group_by(solID) %>% summarise(mroi_sd=sd(roi.m,na.rm=T)) %>% arrange(mroi_sd) %>% filter(solID %in% total_order)
orga<-roi_order%>% filter(media=="organic" & contri>=0.1)
display<-roi_order%>% filter(media=="display" & contri>=0.005)
merge(merge(orga,sd),display,all.x=T)

table(roi_order$media[roi_order$roi_order==1])
table(roi_order$media[roi_order$roi_order==2])
table(roi_order$media[roi_order$roi_order==3])

table(roi_order$media[roi_order$roi_order==4])
table(roi_order$media[roi_order$roi_order==5])
table(roi_order$media[roi_order$roi_order==6])
qc <- subset(decomp_sub,solID %in% total_order & rsq_train>=0.9)
selected_5<-unique(qc$solID)



fwrite(subset(roi_order,solID %in% total_order),file="qc.csv")
## 定下最理想的
qc <- subset(decomp_sub,solID %in% selected_1)
qc <- subset(decomp_sub,solID %in% selected)
unique(qc$rsq_train)
qc$solID[qc$rsq_train==max(qc$rsq_train)]

selected <- "3_125_11"
qc <- subset(roi_order,solID==selected)
decomp_sub$rsq_train[decomp_sub$solID==selected]
decomp_sub$decomp.rssd[decomp_sub$solID==selected]
qc<-subset(decomp_sub,solID==selected)
fwrite(qc,file="qc.csv")


fwrite(subset(hyp,solID==selected),file="qc.csv")

# main_object <- paste0(script_path,"robyn_model.RDS")
# robyn_save(robyn_object = main_object,
#            select_model = selected,                   # 选择最理想的模型
#            InputCollect = robyn_model$InputCollect,
#            OutputCollect = robyn_model$OutputCollect)


selected <- "1_81_5"
hyp<-robyn_model$OutputCollect$resultHypParam
hyp_all<-data.frame()

for(selectedID in selected){
  hyperPar<-unlist(subset(hyp,solID %in% selectedID))
  thetas <- hyperPar[grepl("_thetas", names(hyperPar))]
  scales<-hyperPar[grepl("_scales", names(hyperPar))]
  shapes<-hyperPar[grepl("_shapes", names(hyperPar))]
  alphas<-hyperPar[grepl("_alphas", names(hyperPar))]
  gammas<-hyperPar[grepl("_gammas", names(hyperPar))]

  hyp_df<-data.frame(media=substring(names(alphas),1,nchar(names(alphas))-7),
                  theta=thetas,
                  #scale=scales,
                  #shape=shapes,
                  alpha=alphas,
                  gamma=gammas)

  coefs<-subset(decomp,select=c("solID","rn","coef"),solID %in% selectedID)
  coefs_vector<-coefs$coef
  names(coefs_vector)<-coefs$rn
  hyp_df <- merge(coefs,hyp_df,by.x="rn",by.y="media",all.x=T)
  hyp_df<-subset(hyp_df,coef!=0)
  hyp_all<-rbind(hyp_all,hyp_df)
}




fwrite(hyp_all,file="qc.csv")
##################test one selected ID ###################

selectedID<-"1_81_5"
model<-model_input(robyn_model,selectedID)
df <- organic_df(model)
tmall_df<-sapply(model$media_all,
                       media_response_daily,
                       model_input=model)

fwrite(tmall_df,file="qc.csv")
media_need<-model$media_all
media_need<-c("red_social_spd" ,    
               "tiktok_rtb_spd"   ,   "tiktok_social_spd" , 
               "wechat_social_spd"  , "weibo_social_spd" )
media_need<-c("dy_insite", "social"  ,  "display" )
media_need<-c("live_ljq_spd","live_others_spd")
campaign<-c(as.Date("2021-01-01"),as.Date("2022-12-31"))
campaign<-c(as.Date("2022-01-01"),as.Date("2022-12-31"))
campaign<-c(as.Date("2022-10-24"),as.Date("2022-11-11"))
campaign<-c(as.Date("2022-02-27"),as.Date("2022-03-08"))
campaign<-c(as.Date("2023-02-27"),as.Date("2023-03-08"))
roi_daily <- curveDaily(media_need,model)
roi_campaign <- curveCampaign(media_need,model,spd_range=campaign,promo_range=campaign)
summary<-media_summary(media_need,model,promo_range =campaign)
fwrite(summary,file="qc.csv")
ggplot(subset(roi_daily,media %in% media_need),aes(x=spd_adstock,y=roi.m,colour=media))+
  geom_line()
ggplot(subset(roi_campaign,media %in% media_need),aes(x=spd,y=roi.m,colour=media))+
  geom_line()+
  geom_point(aes(x=summary$spd[1],
                 y= summary$roi.m[1]),
             color='red',shape = 2,
             size=2)+
  geom_point(aes(x=summary$spd[2],
                 y= summary$roi.m[2]),
             color='red',shape = 2,
             size=2)+
  geom_point(aes(x=summary$spd[3],
                 y= summary$roi.m[3]),
             color='red',shape = 2,
        size=2)+
  geom_point(aes(x=summary$spd[4],
                 y= summary$roi.m[4]),
             color='red',shape = 2,
             size=2)+
  geom_point(aes(x=summary$spd[5],
                 y= summary$roi.m[5]),
             color='red',shape = 2,
             size=2)+
  geom_point(aes(x=summary$spd[6],
                 y= summary$roi.m[6]),
             color='red',shape = 2,
             size=2)
